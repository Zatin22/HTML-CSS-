       
'use strict';
// first buttuon

window.addEventListener('mousedown', function(event) {
  var dropd = document.getElementById('down');
  var img = document.getElementById('work');

  if (event.target === img && dropd.style.display === "none") {
    dropd.style.display = "inline-flex";
  } else if (event.target != dropd && event.target.parentNode != dropd) {
    dropd.style.display = 'none';
  }
});
 
// secondb

// window.addEventListener('mousedown', function(event) {
//   var dropd = document.getElementById('sho');
//   var img = document.getElementById('plz');

//   if (event.target === img && dropd.style.display === "none") {
//     dropd.style.display = "inline-flex";
//   } else if (event.target != dropd && event.target.parentNode != dropd) {
//     dropd.style.display = 'none';
//   }
// });

// thirdd buo

window.addEventListener('mousedown', function(event) {
  var dropd = document.getElementById('downn');
  var img = document.getElementById('workk');

  if (event.target === img && dropd.style.display === "none") {
    dropd.style.display = "inline-flex";
  } else if (event.target != dropd && event.target.parentNode != dropd) {
    dropd.style.display = 'none';
  }
});





const modal = document.querySelector('.modal');
const overlay = document.querySelector('.overlay');
const btnCloseModal = document.querySelector('.close-modal');
const btnsOpenModal = document.querySelector('.show-modal');

const openModal = function () {
  modal.classList.remove('hidden');
  overlay.classList.remove('hidden');
};

const closeModal = function () {
  modal.classList.add('hidden');
  overlay.classList.add('hidden');
};

// for (let i = 0; i < btnsOpenModal.length; i++)
  btnsOpenModal.addEventListener('click', openModal);

btnCloseModal.addEventListener('click', closeModal);
overlay.addEventListener('click', closeModal);

document.addEventListener('keydown', function (e) {
  // console.log(e.key);

  if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
    closeModal();
  }
});





// function mFunction() 
//       {
//       var x = document.getElementById("sho");
//       if (x.style.display === "inline-flex") 
//       {
//         x.style.display = "none";
//       } 
//       else 
//        {
//         x.style.display = "inline-flex";
//       }
//      }

//      function myFunction() 
//       {
//       var x = document.getElementById("sho");
//       if (x.style.display === "inline-flex") 
//       {
//         x.style.display = "none";
//       } 
//       else 
//        {
//         x.style.display = "inline-flex";
//       }
//      }

